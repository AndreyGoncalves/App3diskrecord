package com.example.terceiroapp;


import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.terceiroapp.R;

public class MainActivity extends AppCompatActivity {

        private  static final String sSharedPrefFile = "br.edu.ifsc.sj.minhaspreferencias";
        private SharedPreferences mSharedPreferences;
        private int mContador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.mSharedPreferences = getSharedPreferences(sSharedPrefFile, MODE_PRIVATE);
        //vai pegar do disco caso tenha, senão será 0
        mContador = mSharedPreferences.getInt("contador",0);
        TextView textView = findViewById(R.id.contador);
        textView.setText(""+mContador);
    }


    public void decrementar(View view){
        mContador--;

        TextView textView = findViewById(R.id.contador);
        textView.setText(""+mContador);

    }

    public void incrementar(View view) {
        mContador++;

        TextView textView = findViewById(R.id.contador);
        textView.setText("" + mContador);
    }

    public void zerar(View view) {
        SharedPreferences.Editor prefsEditor = mSharedPreferences.edit();
        prefsEditor.clear();
        prefsEditor.apply();

        mContador =0;
        TextView textView = findViewById(R.id.contador);
        textView.setText("" + mContador);
    }

    @Override
    protected void onPause() {
        super.onPause();
            SharedPreferences.Editor prefsEditor = mSharedPreferences.edit();
            prefsEditor.putInt("contador",mContador);
            prefsEditor.apply();

    }
}
